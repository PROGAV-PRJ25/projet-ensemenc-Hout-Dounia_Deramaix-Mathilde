/* public class TerrainDragibus : Terrain
{
    public TerrainDragibus()
        : base("Dragibus", 80, "sucré", "moyenne", "modéré", 15)
    {
    }
} */