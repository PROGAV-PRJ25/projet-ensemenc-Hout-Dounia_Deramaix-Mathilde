/* public class TerrainLangueDeChat : Terrain
{
    public TerrainLangueDeChat()
        : base("Langue de Chat", 100, "acidulé", "élevée", "fort", 20)
    {
    }
} */